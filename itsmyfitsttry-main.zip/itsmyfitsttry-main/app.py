from database import init_db
from ui import launch_ui

init_db()
launch_ui()

